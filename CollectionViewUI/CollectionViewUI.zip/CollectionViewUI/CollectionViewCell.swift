//
//  CollectionViewCell.swift
//  CollectionViewUI
//
//  Created by Kritika Gill on 25/08/21.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
}
